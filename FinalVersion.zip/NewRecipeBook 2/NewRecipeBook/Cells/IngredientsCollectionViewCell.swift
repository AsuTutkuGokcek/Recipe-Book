//
//  IngredientsCollectionViewCell.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import UIKit

class IngredientsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var IngredientImage: UIImageView!
    @IBOutlet weak var IngredientLabel: UILabel!
    @IBOutlet weak var shoppingCartButton: UIButton!
}
