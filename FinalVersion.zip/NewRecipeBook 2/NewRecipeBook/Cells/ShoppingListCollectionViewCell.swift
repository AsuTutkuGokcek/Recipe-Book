//
//  ShoppingListCollectionViewCell.swift
//  NewRecipeBook
//
//  Created by Lab on 20.01.2022.
//

import UIKit

class ShoppingListCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var ingredientImage: UIImageView!
    @IBOutlet weak var ingredientLabel: UILabel!
}
