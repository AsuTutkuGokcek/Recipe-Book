//
//  RecipeDetailViewController.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import UIKit

class RecipeDetailViewController: UIViewController {

    @IBOutlet weak var recipeImageView: UIImageView!
    @IBOutlet weak var recipeText: UITextView!
    
    @IBOutlet var panGestureRecognizer: UIPanGestureRecognizer!
    var selectedRecipe: Recipe?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.title = selectedRecipe?.recipeName
        if let recipe = selectedRecipe {
            self.recipeImageView.image = UIImage(named: recipe.imageName)
            self.recipeText.text = "\(selectedRecipe!.recipe)"
        }
    }
    
    @IBAction func panDetected(_ sender: UIPanGestureRecognizer) {
        let translation = sender.translation(in: self.view)
        self.recipeImageView.transform = self.recipeImageView.transform.translatedBy(x: translation.x, y: translation.y)
        sender.setTranslation(CGPoint.zero, in: self.view)    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let ingredientsViewController = segue.destination as! IngredientsViewController
        ingredientsViewController.selectedRecipe = self.selectedRecipe
    }
}
