//
//  RecipeListViewController.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import UIKit

class RecipeListViewController: UIViewController, UITableViewDataSource {

    let recipeDataSource = RecipeDataSource()
    var favoritesDataSource = FavoritesDataSource()
    var selectedIndex = -1
    
    var foods = [Recipe]()
    var desserts = [Recipe]()
    var drinks = [Recipe]()
    
    @IBOutlet weak var RecipeSegmentedControl: UISegmentedControl!
    @IBOutlet weak var RecipeTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Recipes"
        self.foods = recipeDataSource.getListWithFoodType(foodType: .Foods)
        self.desserts = recipeDataSource.getListWithFoodType(foodType: .Desserts)
        self.drinks = recipeDataSource.getListWithFoodType(foodType: .Drinks)
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if (segue.identifier == "favoritesSegue") {
            let favoritesListViewController = segue.destination as! FavoritesListViewController
            favoritesListViewController.favArray = favoritesDataSource.favoritesArray
        } else if (segue.identifier == "infoSegue") {
            
        } else if (segue.identifier == "shoppingSegue") {
        
        } else {
            let cell = sender as! RecipeTableViewCell
            if let indexPath = self.RecipeTableView.indexPath(for: cell) {
                var recipe = foods[0]
                let selectedIndex = self.RecipeSegmentedControl.selectedSegmentIndex
                switch(selectedIndex) {
                case 0:
                    recipe = foods[indexPath.row]
                    let recipeDetailViewController = segue.destination as! RecipeDetailViewController
                    recipeDetailViewController.selectedRecipe = recipe
                case 1:
                    recipe = desserts[indexPath.row]
                    let recipeDetailViewController = segue.destination as! RecipeDetailViewController
                    recipeDetailViewController.selectedRecipe = recipe
                case 2:
                    recipe = drinks[indexPath.row]
                    let recipeDetailViewController = segue.destination as! RecipeDetailViewController
                    recipeDetailViewController.selectedRecipe = recipe
                default:
                    print("error")
                }
            }
        }
    }
    
    @IBAction func starButtonTouchDown(_ sender: UIButton) {
        var superview = sender.superview
        
        while let view = superview, !(view is UITableViewCell) {
            superview = view.superview
        }
        
        let cell = (superview as? UITableViewCell)!
        let indexPath = self.RecipeTableView.indexPath(for: cell)
        
        var recipe = foods[0]
        let selectedIndex = self.RecipeSegmentedControl.selectedSegmentIndex
        
        switch(selectedIndex) {
        case 0:
            recipe = foods[indexPath!.row]
            favoritesDataSource.appendingToArray(recipeName: recipe.recipeName, imageName: recipe.imageName, foodType: .Foods, recipe: recipe.recipe)
        case 1:
            recipe = desserts[indexPath!.row]
            favoritesDataSource.appendingToArray(recipeName: recipe.recipeName, imageName: recipe.imageName, foodType: .Desserts, recipe: recipe.recipe)
        case 2:
            recipe = drinks[indexPath!.row]
            favoritesDataSource.appendingToArray(recipeName: recipe.recipeName, imageName: recipe.imageName, foodType: .Drinks, recipe: recipe.recipe)
        default:
            print("error")
        }
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(favoritesDataSource.favoritesArray)
            UserDefaults.standard.set(data, forKey: "favorites")
        } catch {
            print("error")
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let selectedIndex = self.RecipeSegmentedControl.selectedSegmentIndex
        switch selectedIndex {
        case 0:
            return foods.count
        case 1:
            return desserts.count
        case 2:
            return drinks.count
        default:
            return 0
        }
    }
    
    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        self.RecipeTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecipeCell", for: indexPath) as! RecipeTableViewCell
        var recipe = foods
        
        let selectedIndex = self.RecipeSegmentedControl.selectedSegmentIndex
        switch selectedIndex {
        case 0:
            recipe = foods
            cell.RecipeLabel.text = recipe[indexPath.row].recipeName
            return cell
        case 1:
            recipe = desserts
            cell.RecipeLabel.text = recipe[indexPath.row].recipeName
            return cell
        case 2:
            recipe = drinks
            cell.RecipeLabel.text = recipe[indexPath.row].recipeName
            return cell
        default:
            return UITableViewCell()
        }
    }
}
