//
//  ViewController.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

