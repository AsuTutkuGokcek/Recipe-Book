//
//  FavoritesListViewController.swift
//  NewRecipeBook
//
//  Created by Lab on 8.01.2022.
//

import UIKit

class FavoritesListViewController: UIViewController {

    let favoritesDataSource = FavoritesDataSource()
    var favArray: Array = [Recipe]()
    
    @IBOutlet weak var FavoritesTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let data = UserDefaults.standard.data(forKey: "favorites") {
            do {
                let decoder = JSONDecoder()
                let ourArray = try decoder.decode([Recipe].self, from: data)
                favArray = ourArray
            } catch {
                print("error")
            }
        }
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let cell = sender as! FavoritesTableViewCell
        if let indexPath = self.FavoritesTable.indexPath(for: cell) {
            var recipe: Recipe?
            recipe = favArray[indexPath.row]
            let recipeDetailViewController = segue.destination as! RecipeDetailViewController
            recipeDetailViewController.selectedRecipe = recipe
        }
    }
    
    func getRealIndex(indexPath: IndexPath) -> Int {
        let realIndex = indexPath.row.quotientAndRemainder(dividingBy: favoritesDataSource.getNumberOfFavorites()).remainder
        return realIndex
    }
}

extension FavoritesListViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavoritesCell", for: indexPath) as! FavoritesTableViewCell
        let fav = favArray[indexPath.row]
        cell.favoritesLabel.text = fav.recipeName
        return cell
    }
}
