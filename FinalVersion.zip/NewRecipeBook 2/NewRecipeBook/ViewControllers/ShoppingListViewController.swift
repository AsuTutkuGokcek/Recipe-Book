//
//  ShoppingListViewController.swift
//  NewRecipeBook
//
//  Created by Lab on 20.01.2022.
//

import UIKit

class ShoppingListViewController: UIViewController {
    
    var shoppingListArray: Array = [Ingredients]()

    @IBOutlet weak var shoppingListCollectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if let data = UserDefaults.standard.data(forKey: "shopping") {
            do {
                let decoder = JSONDecoder()
                let ourArray = try decoder.decode([Ingredients].self, from: data)
                shoppingListArray = ourArray
            } catch {
                print("error")
            }
        }
    }
 
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
    }
}

extension ShoppingListViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return shoppingListArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = collectionView.dequeueReusableCell(withReuseIdentifier: "shoppingCell", for: indexPath) as! ShoppingListCollectionViewCell
        let realIndex = indexPath.row.quotientAndRemainder(dividingBy: shoppingListArray.count).remainder
        
        let ingredient = shoppingListArray[realIndex]
        item.ingredientLabel.text = ingredient.ingredientImageName
        item.ingredientImage.image = UIImage(named: ingredient.ingredientImageName)
        return item
    }
}
