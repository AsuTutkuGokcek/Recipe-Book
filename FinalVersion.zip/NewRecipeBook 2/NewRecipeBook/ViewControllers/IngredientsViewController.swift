//
//  IngredientsViewController.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import UIKit

class IngredientsViewController: UIViewController {
    
    var ingredientsDataSource = IngredientsDataSource()
    var selectedRecipe: Recipe?
    var shoppingListDataSource = ShoppingListDataSource()
    
    @IBOutlet weak var refrigeratorImage: UIImageView!
    @IBOutlet weak var ingredientsCollectionView: UICollectionView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 3) {
            self.openRefrigerator()
        }
    }
    
    private func openRefrigerator() {
        let originalCenter = self.refrigeratorImage.center
        self.refrigeratorImage.center = CGPoint(x: originalCenter.x - self.refrigeratorImage.frame.width, y: originalCenter.y)
    }
    
    @IBAction func shoppingCartTouchDown(_ sender: UIButton) {
        var superview = sender.superview
        while let view = superview, !(view is UICollectionViewCell) {
            superview = view.superview
        }
        let cell = (superview as? UICollectionViewCell)!
        let indexPath = self.ingredientsCollectionView.indexPath(for: cell)
        
        var ingredient: Ingredients
        
        ingredient = ingredientsDataSource.getCorrectIngredients(index: indexPath!.row, recipeName: selectedRecipe?.recipeName)
        
        shoppingListDataSource.appendingToArray(recipeName: ingredient.recipeName, ingredientName: ingredient.ingredientName, ingredientImageName: ingredient.ingredientImageName)
        
        do {
            let encoder = JSONEncoder()
            let data = try encoder.encode(shoppingListDataSource.shoppingArray)
            UserDefaults.standard.set(data, forKey: "shopping")
        } catch {
            print("error")
        }
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let shoppingListViewController = segue.destination as! ShoppingListViewController
        shoppingListViewController.shoppingListArray = shoppingListDataSource.shoppingArray
    }
}

extension IngredientsViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ingredientsDataSource.getNumberOfIngredients()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = collectionView.dequeueReusableCell(withReuseIdentifier: "IngredientCell", for: indexPath) as! IngredientsCollectionViewCell
        let rName = selectedRecipe?.recipeName
        let realIndex = indexPath.row.quotientAndRemainder(dividingBy: ingredientsDataSource.getNumberOfIngredients()).remainder
        
        let ingredient = ingredientsDataSource.getCorrectIngredients(index: realIndex, recipeName: rName)
        
        item.IngredientLabel.text = ingredient.ingredientName
        item.IngredientImage.image = UIImage(named: ingredient.ingredientImageName)
        return item
    }
}
