//
//  FavoritesDataSource.swift
//  NewRecipeBook
//
//  Created by Lab on 8.01.2022.
//

import Foundation

struct FavoritesDataSource {
    var favoritesArray: [Recipe] = []
    
    init() {
        
    }
    
    func getNumberOfFavorites() -> Int {
        return favoritesArray.count
    }
    
    func getFavoritesWithIndex(index: Int) -> Recipe {
        return favoritesArray[index]
    }
    
    mutating func appendingToArray(recipeName: String, imageName: String, foodType: FoodType, recipe: String) {
        favoritesArray.append(Recipe(recipeName: recipeName, imageName: imageName, foodType: foodType, recipe: recipe))
    }
}
