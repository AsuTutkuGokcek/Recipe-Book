//
//  IngredientsDataSource.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import Foundation

struct IngredientsDataSource {
    var ingredientsArray: [Ingredients] = []
    var newArray: [Ingredients] = []
    
    init() {
        ingredientsArray.append(Ingredients(recipeName: "Balsamic Ravioli", ingredientName: "Balsamic Vinegar", ingredientImageName: "Balsamic Vinegar"))
        ingredientsArray.append(Ingredients(recipeName: "Balsamic Ravioli", ingredientName: "Butter", ingredientImageName: "Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Balsamic Ravioli", ingredientName: "Parmesan", ingredientImageName: "Parmesan"))
        ingredientsArray.append(Ingredients(recipeName: "Balsamic Ravioli", ingredientName: "Ravioli", ingredientImageName: "Ravioli"))
        ingredientsArray.append(Ingredients(recipeName: "Balsamic Ravioli", ingredientName: "Walnuts", ingredientImageName: "Walnuts"))
        
        ingredientsArray.append(Ingredients(recipeName: "Tamagoyaki", ingredientName: "Water", ingredientImageName: "Water"))
        ingredientsArray.append(Ingredients(recipeName: "Tamagoyaki", ingredientName: "Soy Sauce", ingredientImageName: "Soy Sauce"))
        ingredientsArray.append(Ingredients(recipeName: "Tamagoyaki", ingredientName: "White Sugar", ingredientImageName: "White Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Tamagoyaki", ingredientName: "Brown Sugar", ingredientImageName: "Brown Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Tamagoyaki", ingredientName: "Egg", ingredientImageName: "Egg"))
        
        ingredientsArray.append(Ingredients(recipeName: "Street Tacos", ingredientName: "Sausage Link", ingredientImageName: "Sausage Link"))
        ingredientsArray.append(Ingredients(recipeName: "Street Tacos", ingredientName: "Chipotle Pepper", ingredientImageName: "Chipotle Pepper"))
        ingredientsArray.append(Ingredients(recipeName: "Street Tacos", ingredientName: "Tortilla", ingredientImageName: "Tortilla"))
        ingredientsArray.append(Ingredients(recipeName: "Street Tacos", ingredientName: "Onion", ingredientImageName: "Onion"))
        ingredientsArray.append(Ingredients(recipeName: "Street Tacos", ingredientName: "Cilantro", ingredientImageName: "Cilantro"))
        
        ingredientsArray.append(Ingredients(recipeName: "Roasted Salmon", ingredientName: "Salmon", ingredientImageName: "Salmon"))
        ingredientsArray.append(Ingredients(recipeName: "Roasted Salmon", ingredientName: "Salt", ingredientImageName: "Salt"))
        ingredientsArray.append(Ingredients(recipeName: "Roasted Salmon", ingredientName: "Butter", ingredientImageName: "Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Roasted Salmon", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Roasted Salmon", ingredientName: "White Wine", ingredientImageName: "White Wine"))
                                            
        ingredientsArray.append(Ingredients(recipeName: "Garlic Chicken Breasts", ingredientName: "Olive Oil", ingredientImageName: "Olive Oil"))
        ingredientsArray.append(Ingredients(recipeName: "Garlic Chicken Breasts", ingredientName: "Lime", ingredientImageName: "Lime"))
        ingredientsArray.append(Ingredients(recipeName: "Garlic Chicken Breasts", ingredientName: "Garlic", ingredientImageName: "Garlic"))
        ingredientsArray.append(Ingredients(recipeName: "Garlic Chicken Breasts", ingredientName: "Salt", ingredientImageName: "Salt"))
        ingredientsArray.append(Ingredients(recipeName: "Garlic Chicken Breasts", ingredientName: "Chicken Breast", ingredientImageName: "Chicken Breast"))
        
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cake", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cake", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cake", ingredientName: "Cocoa", ingredientImageName: "Cocoa"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cake", ingredientName: "Baking Powder", ingredientImageName: "Baking Powder"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cake", ingredientName: "Baking Soda", ingredientImageName: "Baking Soda"))
        
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Chip Cookies", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Chip Cookies", ingredientName: "Baking Soda", ingredientImageName: "Baking Soda"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Chip Cookies", ingredientName: "Butter", ingredientImageName: "Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Chip Cookies", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Chip Cookies", ingredientName: "Egg", ingredientImageName: "Egg"))
        
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cupcakes", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cupcakes", ingredientName: "Cocoa", ingredientImageName: "Cocoa"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cupcakes", ingredientName: "Baking Powder", ingredientImageName: "Baking Powder"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cupcakes", ingredientName: "Butter", ingredientImageName: "Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Chocolate Cupcakes", ingredientName: "Vanilla", ingredientImageName: "Vanilla"))
        
        ingredientsArray.append(Ingredients(recipeName: "Cranberry Cake", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Cranberry Cake", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Cranberry Cake", ingredientName: "Butter", ingredientImageName: "Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Cranberry Cake", ingredientName: "Egg", ingredientImageName: "Egg"))
        ingredientsArray.append(Ingredients(recipeName: "Cranberry Cake", ingredientName: "Baking Soda", ingredientImageName: "Baking Soda"))
        
        ingredientsArray.append(Ingredients(recipeName: "Simple White Cake", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Simple White Cake", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Simple White Cake", ingredientName: "Butter", ingredientImageName: "Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Simple White Cake", ingredientName: "Egg", ingredientImageName: "Egg"))
        ingredientsArray.append(Ingredients(recipeName: "Simple White Cake", ingredientName: "Vanilla", ingredientImageName: "Vanilla"))
        
        ingredientsArray.append(Ingredients(recipeName: "Caramel Frappuccino", ingredientName: "Flour", ingredientImageName: "Flour"))
        ingredientsArray.append(Ingredients(recipeName: "Caramel Frappuccino", ingredientName: "Ice", ingredientImageName: "Ice"))
        ingredientsArray.append(Ingredients(recipeName: "Caramel Frappuccino", ingredientName: "Coffee", ingredientImageName: "Coffee"))
        ingredientsArray.append(Ingredients(recipeName: "Caramel Frappuccino", ingredientName: "Caramel Sauce", ingredientImageName: "Caramel Sauce"))
        ingredientsArray.append(Ingredients(recipeName: "Caramel Frappuccino", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        
        ingredientsArray.append(Ingredients(recipeName: "Long Island Iced Tea", ingredientName: "Ice", ingredientImageName: "Ice"))
        ingredientsArray.append(Ingredients(recipeName: "Long Island Iced Tea", ingredientName: "Vodka", ingredientImageName: "Vodka"))
        ingredientsArray.append(Ingredients(recipeName: "Long Island Iced Tea", ingredientName: "Rum", ingredientImageName: "Rum"))
        ingredientsArray.append(Ingredients(recipeName: "Long Island Iced Tea", ingredientName: "Gin", ingredientImageName: "Gin"))
        ingredientsArray.append(Ingredients(recipeName: "Long Island Iced Tea", ingredientName: "Tequila", ingredientImageName: "Tequila"))
        
        ingredientsArray.append(Ingredients(recipeName: "Mojito", ingredientName: "Mint Leaves", ingredientImageName: "Mint Leaves"))
        ingredientsArray.append(Ingredients(recipeName: "Mojito", ingredientName: "Lime", ingredientImageName: "Lime"))
        ingredientsArray.append(Ingredients(recipeName: "Mojito", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Mojito", ingredientName: "Ice", ingredientImageName: "Ice"))
        ingredientsArray.append(Ingredients(recipeName: "Mojito", ingredientName: "Rum", ingredientImageName: "Rum"))
        
        ingredientsArray.append(Ingredients(recipeName: "Peanut Butter Banana Smoothie", ingredientName: "Banana", ingredientImageName: "Banana"))
        ingredientsArray.append(Ingredients(recipeName: "Peanut Butter Banana Smoothie", ingredientName: "Peanut Butter", ingredientImageName: "Peanut Butter"))
        ingredientsArray.append(Ingredients(recipeName: "Peanut Butter Banana Smoothie", ingredientName: "Milk", ingredientImageName: "Milk"))
        ingredientsArray.append(Ingredients(recipeName: "Peanut Butter Banana Smoothie", ingredientName: "Honey", ingredientImageName: "Honey"))
        ingredientsArray.append(Ingredients(recipeName: "Peanut Butter Banana Smoothie", ingredientName: "Ice", ingredientImageName: "Ice"))
        
        ingredientsArray.append(Ingredients(recipeName: "Sangria", ingredientName: "Red Wine", ingredientImageName: "Red Wine"))
        ingredientsArray.append(Ingredients(recipeName: "Sangria", ingredientName: "Sugar", ingredientImageName: "Sugar"))
        ingredientsArray.append(Ingredients(recipeName: "Sangria", ingredientName: "Pineapple", ingredientImageName: "Pineapple"))
        ingredientsArray.append(Ingredients(recipeName: "Sangria", ingredientName: "Orange", ingredientImageName: "Orange"))
        ingredientsArray.append(Ingredients(recipeName: "Sangria", ingredientName: "Lime", ingredientImageName: "Lime"))
    }
    
    func getNumberOfIngredients() -> Int {
        return 5
    }
    
    func getIngredientWithIndex(index: Int, nArray: [Ingredients]) -> Ingredients {
        return nArray[index]
    }
    
    func getListWithRecipe(recipeName: String?) -> [Ingredients] {
        return ingredientsArray.filter({$0.recipeName == recipeName})
    }
    
    mutating func getCorrectIngredients(index: Int, recipeName: String?) -> Ingredients {
        newArray = getListWithRecipe(recipeName: recipeName)
        return getIngredientWithIndex(index: index, nArray: newArray)
    }
}
