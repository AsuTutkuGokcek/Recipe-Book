//
//  Recipe.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import Foundation

struct Recipe: Codable {
    let recipeName: String
    let imageName: String
    let foodType: FoodType
    let recipe: String
}
