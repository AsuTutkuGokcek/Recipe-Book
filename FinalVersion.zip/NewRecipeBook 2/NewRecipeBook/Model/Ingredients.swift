//
//  Ingredients.swift
//  NewRecipeBook
//
//  Created by Lab on 30.12.2021.
//

import Foundation
import UIKit

struct Ingredients: Codable {
    let recipeName: String
    let ingredientName: String
    let ingredientImageName: String
}
