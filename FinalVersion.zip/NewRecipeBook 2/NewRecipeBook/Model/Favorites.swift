//
//  Favorites.swift
//  NewRecipeBook
//
//  Created by Lab on 12.01.2022.
//

import Foundation

struct Favorites {
    let favoriteName: String
}
