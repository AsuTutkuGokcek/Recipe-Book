//
//  ShoppingListDataSource.swift
//  NewRecipeBook
//
//  Created by Lab on 20.01.2022.
//

import Foundation

struct ShoppingListDataSource {
    var shoppingArray: [Ingredients] = []
    
    init() {
        
    }
    
    func getNumberOfShoppingList() -> Int {
        return shoppingArray.count
    }
    
    func getShoppingItemWithIndex(index: Int) -> Ingredients {
        return shoppingArray[index]
    }
    
    mutating func appendingToArray(recipeName: String, ingredientName: String, ingredientImageName: String) {
        shoppingArray.append(Ingredients(recipeName: recipeName, ingredientName: ingredientName, ingredientImageName: ingredientImageName))
    }
}
